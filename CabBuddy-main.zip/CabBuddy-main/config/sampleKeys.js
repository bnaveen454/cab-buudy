dbPassword = 'Write your own Mongodb database url'

module.exports = {
    mongoURI: dbPassword
};
